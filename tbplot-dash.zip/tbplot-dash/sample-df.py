# -*- coding: utf-8 -*-
import dash
import dash_core_components as dcc
import dash_html_components as html
import json
import urllib.request
import pandas as pd
import plotly.graph_objs as go

app = dash.Dash()

iClick=0
# function to call API and put the response in json format
def grab_data(package_url):
    # Make the HTTP request.
    hdr = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11',
           'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
           'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.3',
           'Accept-Encoding': 'none',
           'Accept-Language': 'en-US,en;q=0.8',
           'Connection': 'keep-alive'}

    req = urllib.request.Request(url = package_url,headers = hdr)
    response = urllib.request.urlopen(req)
    assert response.code == 200

    # Use the json module to load TableBuilder API response into a dictionary.
    result = json.loads(response.read())
    return result


app.layout = html.Div(children=[
    dcc.Location(id='url2', refresh=False),

    html.H1(children='Hello Dash'),

    html.Div(children='''
        Dash: A web application framework for Python.
    '''),

    html.Div(id='page-content'),

    dcc.Dropdown(id='ddmenu',
        value=[],
        multi=True
        ),
    html.Button('Clear Menu', id='clearMenu'),
    html.Button('Clear Plot', id='clearPlot'),

    dcc.Graph(id='try-plot')
])

# call back to plotting graph---------------------------------------------------------------------

@app.callback(dash.dependencies.Output('try-plot', 'figure'),
              [dash.dependencies.Input('url2', 'pathname'),
              dash.dependencies.Input('ddmenu', 'value')])

def display_plot(pathname,ddmenu_val):
    resourceId = pathname[1:]

    # Start to grab the data from TableBuilder API


    url = ('http://www.tablebuilder.singstat.gov.sg/publicfacing/rest/timeseries/tabledata/'
      + str(resourceId) + '?sortBy time asc&limit=2000')

    #the values are kept under the "records" section
    pd.set_option('display.max_colwidth', -1)
    record_data = pd.DataFrame(grab_data(url)['records'])
    filtered_df=pd.DataFrame()
    
    if ddmenu_val != []:
        for iSelect in ddmenu_val:
            filtered_df = filtered_df.append(record_data[record_data.variableCode == iSelect])
    traces = []
    for i in filtered_df.variableCode.unique():
        df_by_variableCode = filtered_df[filtered_df['variableCode'] == i]
        traces.append(go.Scatter(
            x=df_by_variableCode['time'],
            y=df_by_variableCode['value'],
            text=df_by_variableCode['variableName'],
            mode='lines+markers',
            name=i))

    layout = go.Layout(
            title = 'Hello World',
            xaxis = dict(showgrid = False,
                        title = 'Period'),
            yaxis = dict(showgrid = False)
        )
    fig = dict(data=traces,layout=layout)
    return fig
    #return html.Div([
    #     html.H5('You are on page {}'.format(traces))
    #     ])


# call back to populate dropdown---------------------------------------------------------------------

@app.callback(dash.dependencies.Output('ddmenu', 'options'),
              [dash.dependencies.Input('url2', 'pathname')])
def pop_dropdown(pathname):
    resourceId = pathname[1:]

    # Start to grab the data from TableBuilder API
    #lst_ivars = ['All','None']

    url = ('http://www.tablebuilder.singstat.gov.sg/publicfacing/rest/timeseries/tabledata/'
      + str(resourceId) + '?sortBy time asc&limit=2000')

    #the values are kept under the "records" section
    pd.set_option('display.max_colwidth', -1)
    variables_data = pd.DataFrame(grab_data(url)['variables'])
    l1 = list(variables_data['variableCode'])
    l2 = list(variables_data['variableName'])
    #lst_ivars = list([l1[i] + '-' + l2[j] for i in range(len(l1)) for j in range(len(l2)) if i==j])
    #lst_ivars = ['All','None'] + lst_ivars
    ivars = [{'label':i,'value':i} for i in l1]

    return ivars
    #return html.Div([
    #    html.H3('You are on page {}'.format(ivars))
    #])

# call back to clear menu---------------------------------------------------------------------

@app.callback(dash.dependencies.Output('ddmenu','value'), 
            [dash.dependencies.Input('clearMenu', 'n_clicks')])
def clear_Menu(number_of_times_button_has_clicked):

    return []

# call back to clear menu---------------------------------------------------------------------

@app.callback(dash.dependencies.Output('try-plot','relayoutdata'), 
            [dash.dependencies.Input('clearPlot', 'n_clicks'),
            dash.dependencies.Input('url2', 'pathname')])
def clear_plot(number_of_times_button_has_clicked,pathname):
    display_plot(pathname,[])


app.css.append_css({
    'external_url': 'https://codepen.io/chriddyp/pen/bWLwgP.css'
})

if __name__ == '__main__':
    app.run_server(debug=True)