# -*- coding: utf-8 -*-
import dash
import dash_core_components as dcc
import dash_html_components as html
import json
import urllib.request
import pandas as pd
import plotly.graph_objs as go
import datetime

app = dash.Dash()

n=0

# function to call API and put the response in json format
def grab_data(package_url):
    # Make the HTTP request.
    hdr = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11',
           'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
           'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.3',
           'Accept-Encoding': 'none',
           'Accept-Language': 'en-US,en;q=0.8',
           'Connection': 'keep-alive'}

    req = urllib.request.Request(url = package_url,headers = hdr)
    response = urllib.request.urlopen(req)
    assert response.code == 200

    # Use the json module to load TableBuilder API response into a dictionary.
    result = json.loads(response.read())
    return result

def plotTS(crawled_DataFrame,lst_variableCodes):

    filtered_df=pd.DataFrame()
    
    if lst_variableCodes != []:
        for iSelect in lst_variableCodes:
            filtered_df = filtered_df.append(crawled_DataFrame[crawled_DataFrame.variableCode == iSelect])
        traces = []
        for i in filtered_df.variableCode.unique():
            df_by_variableCode = filtered_df[filtered_df['variableCode'] == i]
            traces.append(go.Scatter(
                x=df_by_variableCode['time'],
                y=df_by_variableCode['value'],
                text=df_by_variableCode['variableName'],
                mode='lines+markers',
                name=i))

        layout = go.Layout(
                xaxis = dict(showgrid = False,
                            title = 'Period'),
                yaxis = dict(showgrid = False)
            )
        fig = dict(data=traces,layout=layout)
        return fig




app.layout = html.Div(children=[
    dcc.Location(id='url2', refresh=False),

    html.Div(children='''
        Please select the variables in interest.
    '''),

    # Hidden div inside the app that stores the intermediate value
    html.Div(id='intermediate-value', style={'display':'none'}),
    
    dcc.Dropdown(id='ddmenu',
        value=[],
        multi=True
        ),

    # Trigger a timer to push data into dropdown menu
    dcc.Interval(
            id='interval-component',
            interval=1.5*1000, # in milliseconds
            n_intervals=0),

    dcc.Checklist(id='select-all',
                  options=[{'label': 'Select All', 'value': 1}], values=[]),

    dcc.Graph(id='try-plot')
])

# call back to store data in hidden Div---------------------------------------------------------------------

@app.callback(dash.dependencies.Output('intermediate-value', 'children'),
              [dash.dependencies.Input('url2', 'pathname')])

def JSONdata(pathname):
    if pathname is not None:
        resourceId = pathname[1:]

        # Start to grab the data from TableBuilder API
        testurl = ('http://www.tablebuilder.singstat.gov.sg/publicfacing/rest/timeseries/tabledata/'
          + str(resourceId) + '?sortBy time asc&limit=2')

        #the values are kept under the "records" section
        pd.set_option('display.max_colwidth', -1)
        totalCounts = grab_data(testurl)['total']
        iLoop = 1
        record_data = pd.DataFrame()

        if totalCounts > 2000:
            #divmod[0] is the quotient, [1] is the remainder
            if divmod(totalCounts,2000)[1]==0:
                iLoop = divmod(totalCounts,2000)[0]
            else:
                iLoop = divmod(totalCounts,2000)[0] + 1

        for i in range(iLoop):
            if totalCounts < 2000:
                vOffset = 0
            else:
                vOffset = i*2000 + 1

            url = ('http://www.tablebuilder.singstat.gov.sg/publicfacing/rest/timeseries/tabledata/'
          + str(resourceId) + '?offset='+str(vOffset)+'&sortBy time asc&limit=2000')
            
            record_data = record_data.append(pd.DataFrame(grab_data(url)['records']))

            return record_data.to_json(date_format='iso', orient='split')
            #return html.Div([
            # html.H5('You are on page {}'.format(len(record_data['variableCode'])))
            #])

# call back to plotting graph---------------------------------------------------------------------

@app.callback(dash.dependencies.Output('try-plot', 'figure'),
              [dash.dependencies.Input('url2', 'pathname'),
              dash.dependencies.Input('ddmenu', 'value')])

def display_plot(pathname,ddmenu_val):
    if pathname is not None:
        resourceId = pathname[1:]

        # Start to grab the data from TableBuilder API
        url = ('http://www.tablebuilder.singstat.gov.sg/publicfacing/rest/timeseries/tabledata/'
          + str(resourceId) + '?sortBy time asc&limit=2000')

        #the values are kept under the "records" section
        pd.set_option('display.max_colwidth', -1)
        record_data = pd.DataFrame(grab_data(url)['records'])

        return plotTS(record_data,ddmenu_val)
        #return html.Div([
        #     html.H5('You are on page {}'.format(plotTS(record_data,ddmenu_val)))
        #     ])


# Select All checkbox---------------------------------------------------------------------

@app.callback(
    dash.dependencies.Output('ddmenu', 'value'),
    [dash.dependencies.Input('select-all', 'values')],
    [dash.dependencies.State('ddmenu', 'options'),
     dash.dependencies.State('ddmenu', 'value')])
def test(selected, options, values):
    print(selected)
    if len(selected) > 0:
        if selected[0] == 1:
            return [i['value'] for i in options]
        else:
            return values

# call back to push data to ddmenu---------------------------------------------------------------------

@app.callback(dash.dependencies.Output('ddmenu', 'options'),
              [dash.dependencies.Input('intermediate-value', 'children'),
              dash.dependencies.Input('url2', 'pathname'),
              dash.dependencies.Input('interval-component', 'n_intervals')],
              [],
              [dash.dependencies.Event('interval-component', 'interval')]
                            )

def push2ddmenu(cleandata,pathname,n):
    
    record_data = pd.read_json(cleandata, orient='split')
    variables_data = list(record_data.variableCode.unique())
    ivars = [{'label':i,'value':i} for i in variables_data]
    return ivars

# call back to stop timer once user has selected a value in ddmenu---------------------------------------------------------------------

@app.callback(dash.dependencies.Output('interval-component', 'interval'),
              [dash.dependencies.Input('url2', 'pathname'),
              dash.dependencies.Input('ddmenu', 'value')])

def update_timer(pathname,n):
    if len(n) > 0:
        return 5*60*60*1000
    else:
        return 1.5*1000

    

app.css.append_css({
    'external_url': 'https://codepen.io/chriddyp/pen/bWLwgP.css'
})

if __name__ == '__main__':
    app.run_server(debug=True)