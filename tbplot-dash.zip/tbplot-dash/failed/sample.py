# -*- coding: utf-8 -*-
import dash
import dash_core_components as dcc
import dash_html_components as html
import json
import urllib.request
import pandas as pd
import plotly.graph_objs as go

app = dash.Dash()


# function to call API and put the response in json format
def grab_data(package_url):
    # Make the HTTP request.
    hdr = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11',
           'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
           'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.3',
           'Accept-Encoding': 'none',
           'Accept-Language': 'en-US,en;q=0.8',
           'Connection': 'keep-alive'}

    req = urllib.request.Request(url = package_url,headers = hdr)
    response = urllib.request.urlopen(req)
    assert response.code == 200

    # Use the json module to load TableBuilder API response into a dictionary.
    result = json.loads(response.read())
    return result

app.layout = html.Div(children=[
    dcc.Location(id='url2', refresh=False),

    html.H1(children='Hello Dash'),

    html.Div(children='''
        Dash: A web application framework for Python.
    '''),

    html.Div(id='page-content'),

    dcc.Dropdown(id='ddmenu',
        value=[],
        multi=True
        ),

    dcc.Graph(id='try-plot')
])

# call back to plotting graph---------------------------------------------------------------------

@app.callback(dash.dependencies.Output('try-plot', 'figure'),
              [dash.dependencies.Input('url2', 'pathname'),
              dash.dependencies.Input('ddmenu', 'value')])

def display_plot(pathname,ddmenu_val):
    resourceId = pathname[1:]

    # Start to grab the data from TableBuilder API
    lst_vCode = []
    lst_vName = []
    plot_list=[]

    url = ('http://www.tablebuilder.singstat.gov.sg/publicfacing/rest/timeseries/tabledata/'
      + str(resourceId) + '?sortBy time asc&limit=2000')

    #the values are kept under the "records" section
    record_data = grab_data(url)['records']

    # lst_vCode is to find the list of unique variable codes in this table
    for item in range(len(record_data)):
        lst_vCode.append(record_data[item]['variableCode'])

    lst_vCode = list(set(lst_vCode))

    #construct the dictionary to in preparation for plotting. Each variable is a dictionary containing code, x_list, y_list. the dictionaries are kept as a list.
    for iCode in lst_vCode:
        x_list = []
        y_list = []
        for item in range(len(record_data)):
            if record_data[item]['variableCode'] == iCode:
                x_list.append(record_data[item]['time'])
                y_list.append(record_data[item]['value'])
                iName = record_data[item]['variableName']
                iLvl = record_data[item]['level']
                iFreq = record_data[item]['frequency']
        d = {'code':iCode, 'x':x_list, 'y':y_list, 'name':iName, 'level':iLvl, 'frequency':iFreq}
        plot_list.append(d)

    # Create a trace for plotly
    data = []
    for itrace in range(len(plot_list)):
        myName = plot_list[itrace]['code'] + '-' + iName

        # for iSelect in ddmenu_val:
        #     if iSelect == myName:
        #         iVis = True
        #     else:
        #         iVis = False

        data.append(go.Scatter(
            x = plot_list[itrace]['x'],
            y = plot_list[itrace]['y'],
            name = myName,
            hoverinfo = 'x+y',
            mode = 'lines+markers',
            visible = myName in ddmenu_val,
            showlegend = True)
                   )

    layout = go.Layout(
            title = 'Hello World',
            xaxis = dict(showgrid = False,
                        title = 'Period'),
            yaxis = dict(showgrid = False)
        )

    fig = dict(data=data,layout=layout)

    return fig
    #return html.Div([
    #    html.H5('You are on page {}'.format(fig))
    #])


# call back to populate dropdown---------------------------------------------------------------------

@app.callback(dash.dependencies.Output('ddmenu', 'options'),
              [dash.dependencies.Input('url2', 'pathname')])
def pop_dropdown(pathname):
    resourceId = pathname[1:]

    # Start to grab the data from TableBuilder API
    #lst_ivars = ['All','None']

    url = ('http://www.tablebuilder.singstat.gov.sg/publicfacing/rest/timeseries/tabledata/'
      + str(resourceId) + '?sortBy time asc&limit=2000')

    #the values are kept under the "records" section
    pd.set_option('display.max_colwidth', -1)
    variables_data = pd.DataFrame(grab_data(url)['variables'])
    l1 = list(variables_data['variableCode'])
    l2 = list(variables_data['variableName'])
    lst_ivars = list([l1[i] + '-' + l2[j] for i in range(len(l1)) for j in range(len(l2)) if i==j])
    lst_ivars = ['All','None'] + lst_ivars
    ivars = [{'label':i,'value':i} for i in lst_ivars]

    return ivars
    #return html.Div([
    #    html.H3('You are on page {}'.format(ivars))
    #])

# call back to update chart---------------------------------------------------------------------

# @app.callback(dash.dependencies.Output('page-content', 'children'),
#               [dash.dependencies.Input('ddmenu', 'value')])

# def update_plot(ddmenu_val):

#     return ddmenu_val[1]


app.css.append_css({
    'external_url': 'https://codepen.io/chriddyp/pen/bWLwgP.css'
})

if __name__ == '__main__':
    app.run_server(debug=True)