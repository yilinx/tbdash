import dash
import dash_core_components as dcc
import dash_html_components as html
import plotly.graph_objs as go
import json
import urllib.request
import pandas as pd

app = dash.Dash()

# function to call API and put the response in json format
def grab_data(package_url):
    # Make the HTTP request.
    hdr = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11',
           'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
           'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.3',
           'Accept-Encoding': 'none',
           'Accept-Language': 'en-US,en;q=0.8',
           'Connection': 'keep-alive'}

    req = urllib.request.Request(url = package_url,headers = hdr)
    response = urllib.request.urlopen(req)
    assert response.code == 200

    # Use the json module to load TableBuilder API response into a dictionary.
    result = json.loads(response.read())
    return result


app.layout = html.Div(children=[
    
    dcc.Location(id='url', refresh=False),

    html.H1(children='Hello Dash'),

    html.Div(children='''
        Dash: A web application framework for Python.
    '''),

    dcc.Graph(id='example-graph')
])

@app.callback(dash.dependencies.Output('example-graph', 'figure'),
              [dash.dependencies.Input('url', 'pathname')])

def lines(pathname):
	resourceId = pathname

	# Start to grab the data from TableBuilder API
	lst_vCode = []
	lst_vName = []
	plot_list=[]

	url = ('http://www.tablebuilder.singstat.gov.sg/publicfacing/rest/timeseries/tabledata/'
	  + str(resourceId) + '?sortBy time asc&limit=2000')

	#the values are kept under the "records" section
	record_data = grab_data(url)['records']

	# lst_vCode is to find the list of unique variable codes in this table
	for item in range(len(record_data)):
	    lst_vCode.append(record_data[item]['variableCode'])

	lst_vCode = list(set(lst_vCode))

	#construct the dictionary to in preparation for plotting. Each variable is a dictionary containing code, x_list, y_list. the dictionaries are kept as a list.
	for iCode in lst_vCode:
	    x_list = []
	    y_list = []
	    for item in range(len(record_data)):
	        if record_data[item]['variableCode'] == iCode:
	            x_list.append(record_data[item]['time'])
	            y_list.append(record_data[item]['value'])
	            iName = record_data[item]['variableName']
	            iLvl = record_data[item]['level']
	            iFreq = record_data[item]['frequency']
	    d = {'code':iCode, 'x':x_list, 'y':y_list, 'name':iName, 'level':iLvl, 'frequency':iFreq}
	    plot_list.append(d)

	# Create a trace for plotly
	data = []
	for itrace in range(len(plot_list)):
	    data.append(go.Scatter(
	        x = plot_list[itrace]['x'],
	        y = plot_list[itrace]['y'],
	        name = plot_list[itrace]['code'] + '-' + iName,
	        #text = plot_list[itrace]['code'] + '- <br>' + iName,
	        hoverinfo = 'x+y',
	        mode = 'lines+markers',
	        visible = 'legendonly',
	        showlegend = True)
	               )

	layout = go.Layout(
	        title = 'Hello World',
	        xaxis = dict(showgrid = False,
	                    title = 'Period'),
	        yaxis = dict(showgrid = False)
	    )

return go.Figure(data=data,layout=layout)

if __name__ == '__main__':
    app.run_server(debug=True)